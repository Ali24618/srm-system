import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Add from './components/add';
import Home from './components/home';
import Admin from './components/admin';
import Doctors from './components/doctors';
import Users from './components/users';
import Category from './components/category';
import Adddoc from './components/adddoc';
import Doclist from './components/doclist';
import AddGroup from './components/add_group';
import Services from './components/services';
import Servicesid from './components/servicesid';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Add />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/doctors" element={<Doctors />} />
          <Route path="/users/:id" element={<Users />} />
          <Route path="/home/:id" element={<Home />} />
          <Route path="/category" element={<Category />} />
          <Route path="/adddoc" element={<Adddoc />} />
          <Route path="/services" element={<Services />} />
          <Route path="/doclist/:id" element={<Doclist />} />
          <Route path="/add_group/:id" element={<AddGroup />} />
          <Route path="/servicesid/:id" element={<Servicesid />} />
          {/* Убрать мусор по типу: Alert, Бургер меню */}
          {/* Добавить 2 Таблицы услуги и услуги и цена */}
          {/* Добавить плавное появление блоков при скролле */}
          {/* Добавить новый блок с ценником */}
          {/* Мобильная часть кнопка позвонить перенаправить на номер админа или позвонить и кнопка записаться перенаправить в форму отправки */}
          Убрать проверку на почту
          Поменять название админа
          Сделать выбор иконок при создании услуг
          Сделать так что бы нельзя было войти в другие старницы кроме старницы админа
          Сделать что бы категорию врача можно было менять в доклист
          Слайдер на главном экране
          {/* Добавить смену языка */}
        </Routes>
      </BrowserRouter>
    </div>
  );
}
export default App;
