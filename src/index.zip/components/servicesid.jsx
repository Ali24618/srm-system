import axios from "axios";
import { useEffect, useState } from "react";
import { domain } from "../config/url";
import { useParams } from "react-router-dom";

const Servicesid = () => {
    const [data, setData] = useState([]);
    const [categoriess, setCategoriess] = useState([]);
    const [doc, setDoc] = useState([]);
    const [sercat, setSercat] = useState([]);
    const [name, setName] = useState("");
    const [doctor, setDoctor] = useState("");
    const [price, setPrice] = useState("");
    const [category, setCategory] = useState("");
    const [title, setTitle] = useState("");
    const [show, setShow] = useState(false);

    if (localStorage.getItem('identikay') == null) {
        window.location.href = '/admin';
    }

    let param = useParams();

    let famous = async () => {
        let person = await axios({
            method: "get",
            url: `${domain}/api/services/${param.id}`,
        })
        if (person != null) {
            if (person.status === 200) {
                setData(person.data.services)
                console.log('Данные услуг успешно получены', person);
            }
        }
    }

    let categories = async () => {
        let person = await axios({
            method: "get",
            url: `${domain}/api/category_sevices`,
        })
        console.log('Данные категорий успешно получены', person);
        if (person != null) {
            if (person.status == 200) {
                setCategoriess(person.data.category_sevices)
                console.log('Данные успешно получены', person);
            }
        }
    }

    let doctors = async () => {
        let person = await axios({
            method: "get",
            url: `${domain}/api/doctorslist`,
        })
        console.log('Данные докторов получены', person);
        if (person != null) {
            if (person.status == 200) {
                setDoc(person.data.doctorslist)
                console.log('Данные докторов успешно получены', person);
            }
        }
    }

    let list = async () => {
        let person = await axios({
            method: "get",
            url: `${domain}/api/category_sevices`,
        })
        console.log('Данные докторов получены', person);
        if (person != null) {
            if (person.status == 200) {
                setSercat(person.data.category_sevices)
                console.log('Данные докторов успешно получены', person);
            }
        }
    }

    const Puut = async () => {
        let person = await axios.put(`${domain}/api/services/${param.id}`, {
            title: name || data.title,
            doctor: doctor || data.doctor,
            price: price || data.price,
            category: category || data.category,
        });
        console.log('Работает запрос');
        if (person.status === 200) {
            console.log('Успешно изменено', person);
            setShow(true);
            setTimeout(() => {
                window.location.href = `/services`;
            }, 500);
        }
    };

    const Delete = async (id) => {
        const pred = window.confirm("Вы уверены что хотите удалить")
        if (pred) {
            let person = await axios({
                method: "delete",
                url: `${domain}/api/category_sevices/`,
                params: {
                    id: id,
                },
            });
            console.log('Работает удаление', person);
            if (person != null) {
                if (person.status === 200) {
                    list();
                    console.log('Удалено');
                }
            }
        }
    }

    useEffect(() => {
        famous();
        categories();
        doctors();
        list();
    }, []);
    return (
        <>
            {data != null ?
                <div className="container-fluid mt-4">
                    <div className="row justify-content-center">
                        {show ? (
                            <div className="col-12 text-center pos p-5">
                                <h1 className="block">Успешно</h1>
                            </div>
                        ) : (
                            <div></div>
                        )}
                        <div className="col-8 col-lg-4">
                            <div className="card shadow-lg">
                                <div className="card-header text-center bg-primary text-white">
                                    <h2>Услуги</h2>
                                </div>
                                <div className="card-body">
                                    <div className="mb-3">
                                        <label className="form-label">Название услуги</label>
                                        <input placeholder={data.title} value={name} onChange={(e) => setName(e.target.value)} type="text" className="form-control border border-dark rounded-0 spe" />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Категория услуги</label>
                                        <select className="form-control border border-dark rounded-0" value={category} onChange={(e) => setCategory(e.target.value)}>
                                            <option value="">{data.category}</option>
                                            {categoriess.map(i => (
                                                <option key={i.id} value={i.name}>{i.name}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Цена</label>
                                        <input placeholder={data.price} value={price} onChange={(e) => setPrice(e.target.value)} type="text" className="form-control rounded-0 border border-dark spe" />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Доктор который предоставляет эту услууг</label>
                                        <select className="form-control border border-dark rounded-0" value={doctor} onChange={(e) => setDoctor(e.target.value)}>
                                            <option value="">{data.doctor}</option>
                                            {doc.map(i => (
                                                <option key={i.id} value={i.name}>{i.name}</option>
                                            ))}
                                        </select>
                                    </div>
                                    <button type="submit" className="btn btn-primary w-100" onClick={Puut}>Сохранить</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row mt-3">
                        <div className="col-lg-1"></div>
                        <div className="col-lg-10">
                            <table className="table table-bordered border border-dark">
                                <thead className="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Название услуги</th>
                                        <th>Удалить</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {sercat.length ? (
                                        sercat.map(i => (
                                            <tr key={i.id}>
                                                <td>{i.id}</td>
                                                <td><input placeholder={i.name} type="text" className="form-control border-0" /></td>
                                                <td><i class="fa-solid fa-trash text-danger fa-2x" onClick={() => Delete(i.id)}></i></td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td colSpan="8" className="text-center">
                                                <div class="spinner-border" role="status">
                                                    <span class="visually-hidden">Loading...</span>
                                                </div>
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                :
                <>
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </>
            }
        </>
    )
}
export default Servicesid;