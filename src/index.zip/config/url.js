export const URL = 'http://api.com';
export const domain = 'https://medkenesh.ru';